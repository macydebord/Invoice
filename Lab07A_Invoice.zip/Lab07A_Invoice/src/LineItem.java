public class LineItem
{
    private int quantity;
    private Product product;

    public LineItem(Product product, int quantity)
    {
        this.product = product;
        this.quantity = quantity;
    }

    public double calculateTotal()
    {
        return product.getUnitPrice() * quantity;
    }

    public Product getProduct()
    {
        return product;
    }

    public int getQuantity()
    {
        return quantity;
    }
}