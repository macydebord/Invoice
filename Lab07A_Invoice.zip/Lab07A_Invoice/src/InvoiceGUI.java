import javax.swing.*;
import java.awt.*;

public class InvoiceGUI extends JFrame
{
    private Invoice invoice;
    private JTextArea displayArea;

    public InvoiceGUI()
    {
        invoice = new Invoice();
        displayArea = new JTextArea(10, 40);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        JButton addButton = new JButton("Add Line Item");
        addButton.addActionListener(e -> addLineItem());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        this.add(mainPanel);
        this.setTitle("Invoice");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
    }

    private void addLineItem()
    {
        String productName = JOptionPane.showInputDialog("Enter product name:");
        double unitPrice = Double.parseDouble(JOptionPane.showInputDialog("Enter unit price:"));
        int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter quantity:"));

        Product product = new Product(productName, unitPrice);
        LineItem lineItem = new LineItem(product, quantity);
        invoice.addLineItem(lineItem);

        updateDisplay();
    }

    private void updateDisplay()
    {
        StringBuilder displayText = new StringBuilder();
        for (LineItem item : invoice.getLineItems()) {
            displayText.append(item.getProduct().getName()).append("\t").append(item.getQuantity()).append(" x $").append(item.getProduct().getUnitPrice()).append("\tTotal: $").append(item.calculateTotal()).append("\n");
        }
        displayText.append("\nTotal Amount Due: $").append(invoice.calculateTotal());
        displayArea.setText(displayText.toString());
    }

    public static void main(String[] args)
    {
        new InvoiceGUI();
    }
}
